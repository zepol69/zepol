======================
Genesis
======================

About
-----
The origins of streaming


Attributions
---------------------
- Gkdecrypter by shani_08 | http://tvaddons.ag
- Download Script by spoyser | http://tvaddons.ag
- 4orbs theme by Marquerite | http://tvaddons.ag
- Clean theme by jokster | http://tvaddons.ag
- Embossed theme by jokster | http://tvaddons.ag
- GOne theme by jokster | http://tvaddons.ag
- Metro theme by rayw1986 | http://tvaddons.ag
- Dutch translation by dynamic2 | http://tvaddons.ag
- Greek translation by mezger | http://tvaddons.ag
- Hebrew translation by finalmakerr | http://tvaddons.ag
- Polish translation by kodishu | http://tvaddons.ag
- Portuguese translation by Mafarricos | http://tvaddons.ag


License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html